package com.example.calculatorapk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
